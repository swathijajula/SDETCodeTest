## Features

- Express
- REST API

## Requirements
- [node & npm](https://nodejs.org/en/)

## Installation
- `cd node-express-server-rest-api`
- `npm install`
- `npm start`

### GET Routes
- visit http://localhost:3000
  - /countries
  - /countries/1
