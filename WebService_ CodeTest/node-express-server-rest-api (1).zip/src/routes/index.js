import {countriesRoute} from './countries';

export default {
    countriesRoute,
};
